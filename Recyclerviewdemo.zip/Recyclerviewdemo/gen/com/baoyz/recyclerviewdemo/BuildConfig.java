/** Automatically generated file. DO NOT MODIFY */
package com.baoyz.recyclerviewdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}